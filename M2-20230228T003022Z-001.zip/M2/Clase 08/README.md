![HenryLogo](https://d31uz8lwfmyn8g.cloudfront.net/Assets/logo-henry-white-lg.png)

## Principales Objetivos de Aprendizaje para esta Clase

-Aplicar la interacción entre un lenguaje de programación y motor de bases de datos

## Homework

1. Bajar el CSV de Oferta Gastronómica desde Buenos Aires Data (https://data.buenosaires.gob.ar/dataset/). Idealmente hacer esto con Python.
2. Crear una tabla con los siguientes campos: id_local, nombre, categoria, direccion, barrio, comuna, para posteriormente poblarla con los datos bajados, utilzando el conector desde el script de Python.
3. A partir de tener los datos disponibles, responder a las siguientes preguntas:
   a) ¿Cuál es el barrio con mayor cantidad de Pubs?
   b) Obtener la cantidad de locales por categoría
   c) Obtener la cantidad de restaurantes por comuna